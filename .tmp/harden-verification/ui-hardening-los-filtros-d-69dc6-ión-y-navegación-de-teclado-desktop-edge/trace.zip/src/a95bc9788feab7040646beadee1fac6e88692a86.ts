import AxeBuilder from "@axe-core/playwright";
import { expect, test } from "@playwright/test";
import { DEMO_USERS, login } from "./helpers";

test("las gráficas conservan sus colores bajo CSP y navegación cliente", async ({ page }) => {
  await login(page, DEMO_USERS.director);
  const comprobarSeries = async () => {
    const chart = page.locator("[data-chart]");
    await expect(chart.locator(".recharts-bar-rectangle path").first()).toBeVisible();
    await expect
      .poll(() =>
        chart
          .locator("style")
          .evaluate((el) => el instanceof HTMLStyleElement && Boolean(el.nonce && el.sheet)),
      )
      .toBe(true);
    for (const [serie, token] of [
      ["produccion", "--color-primary"],
      ["gasto", "--color-destructive"],
    ]) {
      const path = chart.locator(`path[fill="var(--color-${serie})"]`).first();
      await expect
        .poll(() =>
          path.evaluate((el, name) => {
            const style = getComputedStyle(el);
            return { fill: style.fill, variable: style.getPropertyValue(`--color-${name}`).trim() };
          }, serie),
        )
        .toEqual({
          fill: serie === "produccion" ? "rgb(244, 119, 33)" : "rgb(220, 38, 38)",
          variable: await chart.evaluate(
            (el, name) => getComputedStyle(el).getPropertyValue(name).trim(),
            token,
          ),
        });
    }
  };
  await comprobarSeries();
  await page.reload();
  await comprobarSeries();
  await page
    .getByRole("navigation", { name: "Navegación principal", exact: true })
    .getByRole("link", { name: "Obras", exact: true })
    .click();
  await page
    .getByRole("navigation", { name: "Navegación principal", exact: true })
    .getByRole("link", { name: "Dashboard", exact: true })
    .click();
  await comprobarSeries();
});

test("facturación y alta de equipo tienen etiquetas accesibles", async ({ page }) => {
  await login(page, DEMO_USERS.director);
  await page.goto("/app/configuracion");
  await expect(page.getByLabel("RFC *", { exact: true })).toHaveValue(/.+/);
  await expect(page.getByRole("combobox", { name: "Régimen fiscal", exact: true })).toBeVisible();
  const results = await new AxeBuilder({ page }).withRules(["label", "button-name"]).analyze();
  expect(results.violations).toEqual([]);
  await page.goto("/app/equipo");
  await page.getByRole("button", { name: "Crear usuario", exact: true }).click();
  const dialog = page.getByRole("dialog");
  await expect(dialog.getByLabel("Nombre completo", { exact: true })).toBeFocused();
  await expect(dialog.getByLabel("Email", { exact: true })).toBeVisible();
  await expect(dialog.getByRole("combobox", { name: "Rol", exact: true })).toBeVisible();
  const fields = await new AxeBuilder({ page }).withRules(["label", "button-name"]).analyze();
  expect(fields.violations).toEqual([]);
  await page.keyboard.press("Escape");
  await expect(dialog).not.toBeVisible();
  await expect(page.getByRole("button", { name: "Crear usuario", exact: true })).toBeFocused();
});

test("los filtros de clientes tienen selección y navegación de teclado", async ({ page }) => {
  await login(page, DEMO_USERS.director);
  await page.goto("/app/catalogos");
  const group = page.getByRole("group", { name: "Filtrar clientes por autorización" });
  const todos = group.getByRole("radio", { name: "Todos", exact: true });
  await expect(todos).toBeChecked();
  await todos.focus();
  await page.keyboard.press("ArrowRight");
  const pendientes = group.getByRole("radio", { name: /Pendientes/ });
  await page.keyboard.press("Space");
  await expect(pendientes).toBeChecked();
  await page.keyboard.press("ArrowLeft");
  await page.keyboard.press("Space");
  await expect(todos).toBeChecked();
  const results = await new AxeBuilder({ page })
    .withRules(["aria-valid-attr-value", "button-name"])
    .analyze();
  expect(results.violations).toEqual([]);
});
